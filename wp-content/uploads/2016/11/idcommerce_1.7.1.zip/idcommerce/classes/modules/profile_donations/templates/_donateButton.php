<div class="profile-donations-button-wrapper">
	<?php echo (isset($donate_button) ? $donate_button : ''); ?>
</div>