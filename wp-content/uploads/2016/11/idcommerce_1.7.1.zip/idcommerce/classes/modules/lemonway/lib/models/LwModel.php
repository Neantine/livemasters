<?php

class LwModel {

}

?>