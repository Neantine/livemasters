<?php
function simple_fes_scripts() {
	
}

function idc_simple_fes_level_1_title($title = '', $post_id) {
	return __('Donate', 'memberdeck');
}

function idc_simple_fes_level_1_limit($limit = '', $post_id) {
	return $limit;
}

function idc_simple_fes_level_1_desc($desc = '', $post_id) {
	return $desc;
}

function idc_simple_fes_level_1_price($price = '', $post_id) {
	return $price;
}
?>