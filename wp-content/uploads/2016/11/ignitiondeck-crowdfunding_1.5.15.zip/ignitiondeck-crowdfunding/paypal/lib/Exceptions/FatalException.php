<?php
/*
 * Paypal FATAL EXCEPTION
 */
class FatalException extends Exception {
	
}

?>