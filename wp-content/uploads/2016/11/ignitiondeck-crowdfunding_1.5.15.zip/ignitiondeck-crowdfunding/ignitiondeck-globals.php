<?php
$project = new ID_Project(null);

/*
1. Currency Code and Value
*/

$cCode = $project->currency_code();
?>