<script type="text/javascript">
				dgFlow = top.dgFlow || top.opener.top.dgFlow; 
					dgFlow.closeFlow(); 
					top.close();
				</script>